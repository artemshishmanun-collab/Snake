# Змейка (Android)

Нативная обёртка (WebView) вокруг игры на HTML/JS. Игра лежит в `app/src/main/assets/index.html`, работает офлайн, разрешений не требует.

## Собрать APK

**Через GitHub Actions (без установки чего-либо):**
1. Создайте репозиторий на GitHub и загрузите туда содержимое этой папки.
2. Вкладка Actions, workflow «Build APK» (запустится сам после push, либо Run workflow).
3. Скачайте артефакт `snake-debug-apk`, внутри `app-debug.apk`.

**Через Android Studio:** откройте папку проекта, Build, Build Bundle(s) / APK(s), Build APK(s).

**Из командной строки** (нужны JDK 17 и Android SDK): `./gradlew assembleDebug`, результат в `app/build/outputs/apk/debug/`.

## Установка на телефон
Скопируйте APK на телефон, откройте его и разрешите установку из неизвестных источников для приложения, через которое открыли файл.

Минимальная версия Android: 8.0.
